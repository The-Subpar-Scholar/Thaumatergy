#pragma once
#include <cstdint>
struct AiSoundParam {
    float Radius;
    float lifeFrame;
    int8_t bSpEffectEnable;
    int8_t Type;
    int8_t fakeTargetType;
    int8_t InterestCategory;
    int8_t UseHitDamageTeam;
};